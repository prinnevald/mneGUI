# mneGUI

This is an application which provides frontend for the MNE Framework. ML part
was mainly taken from https://github.com/fkupilik/MNE_ML and we were focusing
on the PyQt5 frontend.
